import java.io.Serializable;
import java.util.*;

public class CampusNavigatorApp implements Serializable {
    static final long serialVersionUID = 99L;

    public HashMap<Station, Station> predecessors = new HashMap<>();
    public HashMap<Set<Station>, Double> times = new HashMap<>();

    public CampusNavigatorNetwork readCampusNavigatorNetwork(String filename) {
        CampusNavigatorNetwork network = new CampusNavigatorNetwork();
        network.readInput(filename);
        return network;
    }

    /**
     * Calculates the fastest route from the user's selected starting point to 
     * the desired destination, using the campus golf cart network and walking paths.
     * @return List of RouteDirection instances
     */
    public List<RouteDirection> getFastestRouteDirections(CampusNavigatorNetwork network) {
        List<RouteDirection> routeDirections;
        // TODO: Your code goes here

        List<Station> allStations = new ArrayList<>();
        allStations.add(network.startPoint);
        allStations.add(network.destinationPoint);
        for (CartLine line : network.lines) {
            allStations.addAll(line.cartLineStations);
        }

        for (int i = 0; i < allStations.size(); i++) {
            for (int j = i + 1; j < allStations.size(); j++) {
                Station a = allStations.get(i);
                Station b = allStations.get(j);
                double dist = a.coordinates.getDistance(b.coordinates);
                double time = dist / network.averageWalkingSpeed;
                addEdge(a, b, time);
            }
        }

        for (CartLine line : network.lines) {
            List<Station> stations = line.cartLineStations;
            for (int i = 0; i < stations.size() - 1; i++) {
                Station a = stations.get(i);
                Station b = stations.get(i + 1);
                double dist = a.coordinates.getDistance(b.coordinates);
                double time = dist / network.averageCartSpeed;
                addEdge(a, b, time);
            }
        }

        dijkstra(network.startPoint,allStations);
        List<Station> path = getPath(network.destinationPoint);
        routeDirections = buildRouteDirections(path, network.lines);
        return routeDirections;
    }

    public void dijkstra(Station start, List<Station> allStations) {
        Map<Station, Double> minTime = new HashMap<>();
        Set<Station> visited = new HashSet<>();
        PriorityQueue<Station> pq = new PriorityQueue<>(Comparator.comparingDouble(minTime::get));

        for (Station s : allStations) {
            minTime.put(s, Double.POSITIVE_INFINITY);
        }

        minTime.put(start, 0.0);
        pq.add(start);

        while (!pq.isEmpty()) {
            Station current = pq.poll();
            if (visited.contains(current)) continue;
            visited.add(current);

            for (Station neighbor : getNeighbors(current)) {
                double edgeTime = getTimeBetween(current, neighbor);
                double newTime = minTime.get(current) + edgeTime;
                if (newTime < minTime.get(neighbor)) {
                    minTime.put(neighbor, newTime);
                    predecessors.put(neighbor, current);
                    pq.add(neighbor);
                }
            }
        }
    }

    public void addEdge(Station a, Station b, double time) {
        Set<Station> key = new HashSet<>();
        key.add(a);
        key.add(b);
        times.put(key, time);
    }

    public List<Station> getNeighbors(Station station) {
        List<Station> neighbors = new ArrayList<>();
        for (Set<Station> key : times.keySet()) {
            if (key.contains(station)) {
                for (Station s : key) {
                    if (!s.equals(station)) neighbors.add(s);
                }
            }
        }
        return neighbors;
    }

    public double getTimeBetween(Station a, Station b) {
        Set<Station> key = new HashSet<>();
        key.add(a);
        key.add(b);
        return times.getOrDefault(key, Double.POSITIVE_INFINITY);
    }
    public List<Station> getPath(Station destination) {
        LinkedList<Station> path = new LinkedList<>();
        Station step = destination;
        while (step != null) {
            path.addFirst(step);
            step = predecessors.get(step);
        }
        return path;
    }


    public List<RouteDirection> buildRouteDirections(List<Station> path, List<CartLine> lines) {
        List<RouteDirection> directions = new ArrayList<>();

        for (int i = 0; i < path.size() - 1; i++) {
            Station from = path.get(i);
            Station to = path.get(i + 1);
            Set<Station> key = new HashSet<>(List.of(from, to));
            double duration = times.getOrDefault(key, Double.POSITIVE_INFINITY);

            boolean isCartRide = false;
            for (CartLine line : lines) {
                List<Station> sList = line.cartLineStations;
                for (int j = 0; j < sList.size() - 1; j++) {
                    if ((sList.get(j).equals(from) && sList.get(j + 1).equals(to)) ||
                            (sList.get(j).equals(to) && sList.get(j + 1).equals(from))) {
                        isCartRide = true;
                        break;
                    }
                }
                if (isCartRide) break;
            }

            directions.add(new RouteDirection(from.description, to.description, duration, isCartRide));
        }

        return directions;
    }

    /**
     * Function to print the route directions to STDOUT
     */
    public void printRouteDirections(List<RouteDirection> directions) {
        double totalDuration = 0.0;
        for (RouteDirection dir : directions) {
            totalDuration += dir.duration;
        }

        System.out.printf("The fastest route takes %d minute(s).\n", Math.round(totalDuration));
        System.out.println("Directions");
        System.out.println("----------");

        for (int i = 0; i < directions.size(); i++) {
            RouteDirection dir = directions.get(i);
            String type = dir.cartRide ? "Ride the cart" : "Walk";
            System.out.printf("%d. %s from \"%s\" to \"%s\" for %.2f minutes.\n",
                    i + 1, type, dir.startStationName, dir.endStationName, dir.duration);
        }
    }
}
